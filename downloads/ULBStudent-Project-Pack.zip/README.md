# ULBStudent

ULBStudent este o platforma web premium pentru studentii ULBS: profesori, documente, discutii, profil, setari, suport si resurse academice. Proiectul este gandit ca site static usor de urcat pe server, cu integrare Supabase pentru functionalitatile dinamice.

## Structura principala

- `index.html` - landing page premium cu hero, beneficii, functionalitati, impact, testimonials si CTA final.
- `profesori.html`, `professor-profile.html`, `professor-panel.html` - catalog, profil si panel profesor.
- `documente.html` - biblioteca de documente si filtre.
- `comments.html`, `discutie.html`, `subreddit.html` - comunitate, forum si redirect legacy.
- `login.html`, `register.html`, `profile.html`, `settings.html`, `admin.html` - cont, profil, setari si administrare.
- `contact.html`, `raporteaza-problema.html` - suport si raportare.
- `404.html`, `offline.html` - pagini de fallback pentru publicare/PWA.
- `styles-global.css`, `app-polish.css`, `styles-documents.css`, `styles-professors.css`, `styles-subreddit.css`, `toast-notifications.css` - sistem vizual si stiluri pe module.
- `interactive.js`, `auth.js`, `professors-filtering.js`, `professor-profile.js`, `supabase-client.js` - interactiuni, autentificare si integrare date.
- `downloads/ULBStudent-Project-Pack.zip` - fisierul de download folosit de butoanele din site.

## Rulare locala

Varianta simpla, fara build:

```bash
python -m http.server 5500
```

Apoi deschide:

```text
http://localhost:5500/index.html
```

Daca ai Node instalat, poti folosi si:

```bash
npm run dev
```

## Upload pe server

1. Urca toate fisierele si folderele din radacina proiectului pe hosting static.
2. Pastreaza structura folderelor: `assets/`, `downloads/`, `public/`, fisierele `.html`, `.css`, `.js`.
3. Configureaza serverul sa serveasca `index.html` ca pagina principala.
4. Configureaza fallback 404 catre `404.html`, daca hostingul permite.
5. Daca folosesti HTTPS si domeniu propriu, actualizeaza `sitemap.xml` si `robots.txt` cu domeniul final.

## Unde modifici continutul

- Textele din landing page: `index.html`.
- Culori, spacing, radius, umbre, responsive si polish global: `app-polish.css` si `styles-global.css`.
- Stiluri pentru documente: `styles-documents.css`.
- Stiluri pentru profesori: `styles-professors.css`.
- Stiluri pentru discutii/forum: `styles-subreddit.css`.
- Footer global, command palette, tema, meniu mobil, animatii si micro-interactiuni: `interactive.js`.
- Logo-uri si favicon: `assets/Logos and icons/`.

## Download proiect/CV/aplicatie

Butoanele de download folosesc:

```text
downloads/ULBStudent-Project-Pack.zip
```

Pentru a schimba fisierul:

1. Pune arhiva/PDF-ul/CV-ul final in folderul `downloads/`.
2. Inlocuieste `href="downloads/ULBStudent-Project-Pack.zip"` in `index.html` si `interactive.js`.
3. Actualizeaza si `downloads/ulbstudent-project-kit.txt`, daca vrei ca placeholder-ul sa descrie noul fisier.

## Functionalitati UI adaugate

- Header premium sticky cu blur.
- Meniu mobil responsive.
- Smooth scroll pentru linkuri interne.
- Animatii pe scroll.
- Back-to-top.
- Hover/focus states accesibile.
- Command palette cu `Ctrl + K` / `Cmd + K`.
- Counter animation pentru statistici.
- Download local functional.
- Pagina `404.html`.
- Pagina `offline.html` si service worker actualizat.
- `robots.txt` si `sitemap.xml`.

## Supabase si servicii externe

Proiectul foloseste Supabase pentru autentificare, roluri, profesori, recenzii, discutii, documente si date dinamice. Configureaza datele in:

```text
supabase-client.js
```

Ruleaza SQL-ul de productie cand conectezi proiectul la un Supabase nou:

```text
SUPABASE_PRODUCTION_SETUP.sql
supabase_professors_seed.sql
```

Site-ul poate fi urcat static, dar datele dinamice depind de Supabase si de politicile RLS corecte.

## Verificari recomandate inainte de prezentare

1. Deschide `index.html`, `profesori.html`, `documente.html`, `comments.html`, `login.html`, `register.html`, `profile.html`, `settings.html`, `contact.html`.
2. Testeaza light/dark mode.
3. Testeaza meniul mobil.
4. Testeaza `Ctrl + K`.
5. Testeaza butonul de download.
6. Testeaza login/register dupa configurarea Supabase.
